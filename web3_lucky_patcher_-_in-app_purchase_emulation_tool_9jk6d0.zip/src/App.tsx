import React, { useState } from 'react';
import { Header } from './components/Header';
import { AppCard } from './components/AppCard';
import { PatchCard } from './components/PatchCard';
import { PurchaseHistory } from './components/PurchaseHistory';
import { CreatePatchModal } from './components/CreatePatchModal';
import { useWeb3Store } from './store/useWeb3Store';
import { 
  Search, 
  Filter, 
  Plus, 
  ShoppingBag, 
  Shield, 
  TrendingUp,
  Zap,
  Lock,
  Unlock,
  X
} from 'lucide-react';

function App() {
  const {
    apps,
    patches,
    purchases,
    selectedApp,
    setSelectedApp,
    applyPatch,
    emulatePurchase,
    createPatch,
    isConnected
  } = useWeb3Store();

  const [searchQuery, setSearchQuery] = useState('');
  const [showCreatePatch, setShowCreatePatch] = useState(false);
  const [activeTab, setActiveTab] = useState<'apps' | 'patches' | 'purchases'>('apps');

  const filteredApps = apps.filter(app =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.packageId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const appPatches = selectedApp
    ? patches.filter(p => p.appId === selectedApp.id)
    : [];

  return (
    <div className="min-h-screen bg-[#0F172A] text-white">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#3B82F6]/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#8B5CF6]/20 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-[#10B981]/10 rounded-full blur-3xl animate-pulse delay-2000" />
      </div>

      <Header />

      <main className="relative pt-24 pb-12 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#3B82F6]/20 to-[#8B5CF6]/20 rounded-full border border-[#8B5CF6]/30 mb-6">
              <Zap className="w-4 h-4 text-[#f59e0b]" />
              <span className="text-sm font-medium text-white">Web3 Powered Patching</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-[#3B82F6] via-[#8B5CF6] to-[#10B981] bg-clip-text text-transparent">
              Lucky Patcher Web3
            </h1>
            <p className="text-xl text-[#A3A3A3] max-w-2xl mx-auto">
              Emulate in-app purchases, bypass license verification, and create custom patches on the blockchain
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Total Apps', value: apps.length, icon: Shield, color: 'from-[#3B82F6] to-[#8B5CF6]' },
              { label: 'Active Patches', value: patches.length, icon: Lock, color: 'from-[#8B5CF6] to-[#f472b6]' },
              { label: 'Emulated Purchases', value: purchases.length, icon: ShoppingBag, color: 'from-[#10B981] to-[#3B82F6]' },
              { label: 'Success Rate', value: '98.7%', icon: TrendingUp, color: 'from-[#f59e0b] to-[#ef4444]' }
            ].map((stat, index) => (
              <div
                key={index}
                className="relative group bg-[#262626]/50 backdrop-blur-sm rounded-xl border border-[#2F2F2F] hover:border-[#8B5CF6]/50 transition-all duration-300 overflow-hidden"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-5 group-hover:opacity-10 transition-opacity`} />
                <div className="relative p-5">
                  <div className="flex items-center justify-between mb-2">
                    <stat.icon className="w-5 h-5 text-[#A3A3A3]" />
                    <div className={`p-1.5 bg-gradient-to-br ${stat.color} rounded-lg`}>
                      <div className="w-2 h-2 bg-white rounded-full" />
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-[#A3A3A3]">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#A3A3A3]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search apps by name or package ID..."
                className="w-full pl-12 pr-4 py-3 bg-[#262626]/50 backdrop-blur-sm border border-[#2F2F2F] rounded-xl text-white placeholder-[#A3A3A3] focus:outline-none focus:border-[#8B5CF6] transition-colors"
              />
            </div>
            <button className="px-6 py-3 bg-[#262626]/50 backdrop-blur-sm border border-[#2F2F2F] rounded-xl text-white hover:border-[#8B5CF6]/50 transition-colors flex items-center gap-2">
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-8 overflow-x-auto">
            {[
              { id: 'apps', label: 'Apps', icon: Shield },
              { id: 'patches', label: 'Patches', icon: Lock },
              { id: 'purchases', label: 'Purchase History', icon: ShoppingBag }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/50'
                    : 'bg-[#262626]/50 text-[#A3A3A3] hover:text-white hover:bg-[#262626]'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Content */}
          {!isConnected ? (
            <div className="text-center py-20">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-2xl mb-6">
                <Unlock className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Connect Your Wallet</h3>
              <p className="text-[#A3A3A3] mb-6">
                Connect your Web3 wallet to start patching apps and emulating purchases
              </p>
            </div>
          ) : (
            <>
              {activeTab === 'apps' && !selectedApp && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredApps.map((app) => (
                    <AppCard
                      key={app.id}
                      app={app}
                      onClick={() => setSelectedApp(app)}
                    />
                  ))}
                </div>
              )}

              {activeTab === 'apps' && selectedApp && (
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => setSelectedApp(null)}
                        className="p-2 hover:bg-[#262626] rounded-lg transition-colors"
                      >
                        <X className="w-5 h-5 text-[#A3A3A3]" />
                      </button>
                      <img
                        src={selectedApp.icon}
                        alt={selectedApp.name}
                        className="w-16 h-16 rounded-xl border-2 border-[#2F2F2F]"
                      />
                      <div>
                        <h2 className="text-2xl font-bold text-white">{selectedApp.name}</h2>
                        <p className="text-sm text-[#A3A3A3] font-mono">{selectedApp.packageId}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowCreatePatch(true)}
                      className="px-6 py-3 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] rounded-xl text-white font-medium hover:scale-105 hover:shadow-lg hover:shadow-[#8B5CF6]/50 transition-all flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5" />
                      <span>Create Patch</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {appPatches.map((patch) => (
                      <PatchCard
                        key={patch.id}
                        patch={patch}
                        onApply={applyPatch}
                      />
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'patches' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {patches.map((patch) => (
                    <PatchCard
                      key={patch.id}
                      patch={patch}
                      onApply={applyPatch}
                    />
                  ))}
                </div>
              )}

              {activeTab === 'purchases' && (
                <div className="max-w-3xl mx-auto">
                  <PurchaseHistory purchases={purchases} />
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {showCreatePatch && selectedApp && (
        <CreatePatchModal
          appId={selectedApp.id}
          appName={selectedApp.name}
          onClose={() => setShowCreatePatch(false)}
          onCreate={createPatch}
        />
      )}
    </div>
  );
}

export default App;
