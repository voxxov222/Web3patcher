import { create } from 'zustand';

interface App {
  id: string;
  name: string;
  packageId: string;
  icon: string;
  version: string;
  size: string;
  patches: number;
  downloads: number;
  rating: number;
}

interface Patch {
  id: string;
  appId: string;
  type: 'iap_emulation' | 'license_verification' | 'custom_patch' | 'remove_ads' | 'unlock_premium';
  name: string;
  description: string;
  status: 'active' | 'pending' | 'failed';
  downloads: number;
  rating: number;
  creator: string;
  timestamp: number;
}

interface Purchase {
  id: string;
  appName: string;
  itemName: string;
  amount: string;
  timestamp: number;
  status: 'emulated' | 'verified' | 'pending';
}

interface Web3Store {
  isConnected: boolean;
  address: string | null;
  balance: string;
  chainId: number;
  apps: App[];
  patches: Patch[];
  purchases: Purchase[];
  selectedApp: App | null;
  
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  setSelectedApp: (app: App | null) => void;
  applyPatch: (patchId: string) => Promise<void>;
  emulatePurchase: (appId: string, itemName: string, amount: string) => Promise<void>;
  createPatch: (patch: Omit<Patch, 'id' | 'downloads' | 'rating' | 'timestamp'>) => Promise<void>;
}

export const useWeb3Store = create<Web3Store>((set, get) => ({
  isConnected: false,
  address: null,
  balance: '0.0',
  chainId: 1,
  selectedApp: null,
  
  apps: [
    {
      id: '1',
      name: 'Crypto Legends',
      packageId: 'com.game.cryptolegends',
      icon: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=200&h=200&fit=crop',
      version: '2.4.1',
      size: '156 MB',
      patches: 8,
      downloads: 45230,
      rating: 4.8
    },
    {
      id: '2',
      name: 'NFT Marketplace Pro',
      packageId: 'com.nft.marketplace',
      icon: 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d?w=200&h=200&fit=crop',
      version: '1.9.3',
      size: '89 MB',
      patches: 12,
      downloads: 67890,
      rating: 4.9
    },
    {
      id: '3',
      name: 'DeFi Wallet Plus',
      packageId: 'com.defi.walletplus',
      icon: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=200&h=200&fit=crop',
      version: '3.2.0',
      size: '124 MB',
      patches: 6,
      downloads: 89450,
      rating: 4.7
    },
    {
      id: '4',
      name: 'Blockchain Explorer',
      packageId: 'com.blockchain.explorer',
      icon: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=200&h=200&fit=crop',
      version: '4.1.2',
      size: '67 MB',
      patches: 15,
      downloads: 123400,
      rating: 4.6
    },
    {
      id: '5',
      name: 'Token Swap Master',
      packageId: 'com.swap.tokenmaster',
      icon: 'https://images.unsplash.com/photo-1622630998477-20aa696ecb05?w=200&h=200&fit=crop',
      version: '2.8.5',
      size: '98 MB',
      patches: 10,
      downloads: 56780,
      rating: 4.5
    },
    {
      id: '6',
      name: 'MetaVerse Builder',
      packageId: 'com.meta.builder',
      icon: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=200&h=200&fit=crop',
      version: '1.5.0',
      size: '234 MB',
      patches: 9,
      downloads: 34560,
      rating: 4.9
    },
    {
      id: '7',
      name: 'Crypto Mining Sim',
      packageId: 'com.mining.simulator',
      icon: 'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=200&h=200&fit=crop',
      version: '3.0.1',
      size: '145 MB',
      patches: 7,
      downloads: 78900,
      rating: 4.4
    },
    {
      id: '8',
      name: 'DAO Governance',
      packageId: 'com.dao.governance',
      icon: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?w=200&h=200&fit=crop',
      version: '2.1.4',
      size: '76 MB',
      patches: 11,
      downloads: 45670,
      rating: 4.7
    }
  ],
  
  patches: [
    {
      id: 'p1',
      appId: '1',
      type: 'iap_emulation',
      name: 'Unlimited Coins',
      description: 'Emulate in-app purchases for unlimited game currency',
      status: 'active',
      downloads: 12340,
      rating: 4.9,
      creator: '0x742d...3f4a',
      timestamp: Date.now() - 86400000
    },
    {
      id: 'p2',
      appId: '1',
      type: 'unlock_premium',
      name: 'Premium Features Unlock',
      description: 'Unlock all premium features and characters',
      status: 'active',
      downloads: 9876,
      rating: 4.8,
      creator: '0x8a3c...7b2d',
      timestamp: Date.now() - 172800000
    },
    {
      id: 'p3',
      appId: '2',
      type: 'license_verification',
      name: 'License Bypass',
      description: 'Bypass license verification for full access',
      status: 'active',
      downloads: 15670,
      rating: 4.7,
      creator: '0x5f9a...1c8e',
      timestamp: Date.now() - 259200000
    },
    {
      id: 'p4',
      appId: '2',
      type: 'remove_ads',
      name: 'Ad-Free Experience',
      description: 'Remove all advertisements from the app',
      status: 'active',
      downloads: 23450,
      rating: 5.0,
      creator: '0x3d7b...9a4f',
      timestamp: Date.now() - 345600000
    },
    {
      id: 'p5',
      appId: '3',
      type: 'custom_patch',
      name: 'Enhanced Security',
      description: 'Add additional security layers and encryption',
      status: 'active',
      downloads: 8900,
      rating: 4.6,
      creator: '0x1e4c...6d2a',
      timestamp: Date.now() - 432000000
    }
  ],
  
  purchases: [
    {
      id: 'pur1',
      appName: 'Crypto Legends',
      itemName: '10,000 Gold Coins',
      amount: '4.99',
      timestamp: Date.now() - 3600000,
      status: 'emulated'
    },
    {
      id: 'pur2',
      appName: 'NFT Marketplace Pro',
      itemName: 'Premium Subscription',
      amount: '9.99',
      timestamp: Date.now() - 7200000,
      status: 'verified'
    },
    {
      id: 'pur3',
      appName: 'DeFi Wallet Plus',
      itemName: 'Advanced Features Pack',
      amount: '14.99',
      timestamp: Date.now() - 10800000,
      status: 'emulated'
    }
  ],
  
  connectWallet: async () => {
    // Mock wallet connection
    await new Promise(resolve => setTimeout(resolve, 1500));
    set({
      isConnected: true,
      address: '0x742d35Cc6634C0532925a3b844Bc9e7595f3f4a',
      balance: '2.4567',
      chainId: 1
    });
  },
  
  disconnectWallet: () => {
    set({
      isConnected: false,
      address: null,
      balance: '0.0'
    });
  },
  
  setSelectedApp: (app) => {
    set({ selectedApp: app });
  },
  
  applyPatch: async (patchId: string) => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const patches = get().patches.map(p => 
      p.id === patchId 
        ? { ...p, downloads: p.downloads + 1, status: 'active' as const }
        : p
    );
    set({ patches });
  },
  
  emulatePurchase: async (appId: string, itemName: string, amount: string) => {
    await new Promise(resolve => setTimeout(resolve, 1500));
    const app = get().apps.find(a => a.id === appId);
    const newPurchase: Purchase = {
      id: `pur${Date.now()}`,
      appName: app?.name || 'Unknown App',
      itemName,
      amount,
      timestamp: Date.now(),
      status: 'emulated'
    };
    set({ purchases: [newPurchase, ...get().purchases] });
  },
  
  createPatch: async (patch) => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const newPatch: Patch = {
      ...patch,
      id: `p${Date.now()}`,
      downloads: 0,
      rating: 0,
      timestamp: Date.now()
    };
    set({ patches: [newPatch, ...get().patches] });
  }
}));
