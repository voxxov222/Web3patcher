import React from 'react';
import { ShoppingBag, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface Purchase {
  id: string;
  appName: string;
  itemName: string;
  amount: string;
  timestamp: number;
  status: 'emulated' | 'verified' | 'pending';
}

interface PurchaseHistoryProps {
  purchases: Purchase[];
}

export const PurchaseHistory: React.FC<PurchaseHistoryProps> = ({ purchases }) => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'emulated': return <CheckCircle className="w-4 h-4 text-[#10B981]" />;
      case 'verified': return <CheckCircle className="w-4 h-4 text-[#3B82F6]" />;
      case 'pending': return <Clock className="w-4 h-4 text-[#f59e0b]" />;
      default: return <AlertCircle className="w-4 h-4 text-[#ef4444]" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'emulated': return 'text-[#10B981]';
      case 'verified': return 'text-[#3B82F6]';
      case 'pending': return 'text-[#f59e0b]';
      default: return 'text-[#ef4444]';
    }
  };

  return (
    <div className="space-y-3">
      {purchases.map((purchase) => (
        <div
          key={purchase.id}
          className="group relative bg-[#262626]/50 backdrop-blur-sm rounded-xl border border-[#2F2F2F] hover:border-[#8B5CF6]/50 transition-all duration-300 overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[#3B82F6]/5 to-[#8B5CF6]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          
          <div className="relative p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <div className="p-2 bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-lg">
                  <ShoppingBag className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold text-white mb-1">
                    {purchase.itemName}
                  </h4>
                  <p className="text-xs text-[#A3A3A3] mb-2">
                    {purchase.appName}
                  </p>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(purchase.status)}
                    <span className={`text-xs font-medium ${getStatusColor(purchase.status)}`}>
                      {purchase.status.charAt(0).toUpperCase() + purchase.status.slice(1)}
                    </span>
                    <span className="text-xs text-[#A3A3A3]">
                      {new Date(purchase.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-lg font-bold text-white">
                  ${purchase.amount}
                </span>
                <p className="text-xs text-[#A3A3A3]">USD</p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
