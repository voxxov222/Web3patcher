import React, { useState } from 'react';
import { X, Shield, Loader } from 'lucide-react';

interface CreatePatchModalProps {
  appId: string;
  appName: string;
  onClose: () => void;
  onCreate: (patch: any) => Promise<void>;
}

export const CreatePatchModal: React.FC<CreatePatchModalProps> = ({
  appId,
  appName,
  onClose,
  onCreate
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'iap_emulation',
    description: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);
    
    await onCreate({
      appId,
      ...formData,
      status: 'active',
      creator: '0x742d...3f4a'
    });
    
    setIsCreating(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-[#171717] rounded-2xl border border-[#2F2F2F] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6]/10 via-transparent to-[#8B5CF6]/10" />
        
        <div className="relative">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-[#2F2F2F]">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-lg">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Create New Patch</h3>
                <p className="text-sm text-[#A3A3A3]">{appName}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#262626] rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-[#A3A3A3]" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Patch Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#262626] border border-[#2F2F2F] rounded-lg text-white placeholder-[#A3A3A3] focus:outline-none focus:border-[#8B5CF6] transition-colors"
                placeholder="Enter patch name"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Patch Type
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#262626] border border-[#2F2F2F] rounded-lg text-white focus:outline-none focus:border-[#8B5CF6] transition-colors"
              >
                <option value="iap_emulation">IAP Emulation</option>
                <option value="license_verification">License Verification</option>
                <option value="remove_ads">Remove Ads</option>
                <option value="unlock_premium">Unlock Premium</option>
                <option value="custom_patch">Custom Patch</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-4 py-2.5 bg-[#262626] border border-[#2F2F2F] rounded-lg text-white placeholder-[#A3A3A3] focus:outline-none focus:border-[#8B5CF6] transition-colors resize-none"
                placeholder="Describe what this patch does"
                rows={4}
                required
              />
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2.5 bg-[#262626] border border-[#2F2F2F] rounded-lg text-white font-medium hover:bg-[#2F2F2F] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isCreating}
                className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] rounded-lg text-white font-medium hover:scale-[1.02] hover:shadow-lg hover:shadow-[#8B5CF6]/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCreating ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader className="w-4 h-4 animate-spin" />
                    <span>Creating...</span>
                  </div>
                ) : (
                  'Create Patch'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
