import React from 'react';
import { Download, Star, Package } from 'lucide-react';

interface AppCardProps {
  app: {
    id: string;
    name: string;
    packageId: string;
    icon: string;
    version: string;
    size: string;
    patches: number;
    downloads: number;
    rating: number;
  };
  onClick: () => void;
}

export const AppCard: React.FC<AppCardProps> = ({ app, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="group relative bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F] hover:border-[#8B5CF6]/50 transition-all duration-300 cursor-pointer overflow-hidden hover:scale-[1.02] hover:shadow-xl hover:shadow-[#8B5CF6]/20"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6]/5 via-transparent to-[#8B5CF6]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="relative p-5">
        <div className="flex items-start gap-4">
          {/* App Icon */}
          <div className="relative flex-shrink-0">
            <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-xl blur-md opacity-0 group-hover:opacity-50 transition-opacity" />
            <img
              src={app.icon}
              alt={app.name}
              className="relative w-16 h-16 rounded-xl object-cover border-2 border-[#2F2F2F] group-hover:border-[#8B5CF6]/50 transition-colors"
            />
          </div>

          {/* App Info */}
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-white mb-1 truncate group-hover:text-[#8B5CF6] transition-colors">
              {app.name}
            </h3>
            <p className="text-xs text-[#A3A3A3] mb-2 truncate font-mono">
              {app.packageId}
            </p>
            
            <div className="flex items-center gap-4 text-xs text-[#A3A3A3]">
              <span className="flex items-center gap-1">
                <Package className="w-3 h-3" />
                v{app.version}
              </span>
              <span>{app.size}</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-4 pt-4 border-t border-[#2F2F2F] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-[#f59e0b] fill-[#f59e0b]" />
              <span className="text-sm font-medium text-white">{app.rating}</span>
            </div>
            <div className="flex items-center gap-1 text-[#A3A3A3]">
              <Download className="w-4 h-4" />
              <span className="text-sm">{(app.downloads / 1000).toFixed(1)}K</span>
            </div>
          </div>
          
          <div className="px-3 py-1 bg-gradient-to-r from-[#3B82F6]/20 to-[#8B5CF6]/20 rounded-full border border-[#8B5CF6]/30">
            <span className="text-xs font-medium text-[#8B5CF6]">
              {app.patches} Patches
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
