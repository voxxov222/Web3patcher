import React, { useState } from 'react';
import { Shield, Download, Star, User, Clock, CheckCircle, Loader } from 'lucide-react';

interface PatchCardProps {
  patch: {
    id: string;
    type: string;
    name: string;
    description: string;
    status: string;
    downloads: number;
    rating: number;
    creator: string;
    timestamp: number;
  };
  onApply: (patchId: string) => Promise<void>;
}

export const PatchCard: React.FC<PatchCardProps> = ({ patch, onApply }) => {
  const [isApplying, setIsApplying] = useState(false);
  const [isApplied, setIsApplied] = useState(false);

  const handleApply = async () => {
    setIsApplying(true);
    await onApply(patch.id);
    setIsApplying(false);
    setIsApplied(true);
  };

  const getPatchTypeColor = (type: string) => {
    switch (type) {
      case 'iap_emulation': return 'from-[#3B82F6] to-[#8B5CF6]';
      case 'license_verification': return 'from-[#10B981] to-[#3B82F6]';
      case 'remove_ads': return 'from-[#f59e0b] to-[#ef4444]';
      case 'unlock_premium': return 'from-[#8B5CF6] to-[#f472b6]';
      default: return 'from-[#A3A3A3] to-[#737373]';
    }
  };

  const getPatchTypeLabel = (type: string) => {
    return type.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="group relative bg-[#262626]/50 backdrop-blur-sm rounded-xl border border-[#2F2F2F] hover:border-[#8B5CF6]/50 transition-all duration-300 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6]/5 via-transparent to-[#8B5CF6]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="relative p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`p-2 bg-gradient-to-br ${getPatchTypeColor(patch.type)} rounded-lg`}>
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="text-base font-semibold text-white group-hover:text-[#8B5CF6] transition-colors">
                {patch.name}
              </h4>
              <span className={`inline-block mt-1 px-2 py-0.5 bg-gradient-to-r ${getPatchTypeColor(patch.type)} bg-opacity-20 rounded text-xs font-medium text-white`}>
                {getPatchTypeLabel(patch.type)}
              </span>
            </div>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-[#A3A3A3] mb-4 line-clamp-2">
          {patch.description}
        </p>

        {/* Stats */}
        <div className="flex items-center gap-4 mb-4 text-xs text-[#A3A3A3]">
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-[#f59e0b] fill-[#f59e0b]" />
            <span>{patch.rating}</span>
          </div>
          <div className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            <span>{(patch.downloads / 1000).toFixed(1)}K</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="w-3 h-3" />
            <span className="font-mono">{patch.creator}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{new Date(patch.timestamp).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Apply Button */}
        <button
          onClick={handleApply}
          disabled={isApplying || isApplied}
          className={`w-full py-2.5 rounded-lg font-medium text-white transition-all ${
            isApplied
              ? 'bg-[#10B981] cursor-default'
              : isApplying
              ? 'bg-[#8B5CF6]/50 cursor-wait'
              : 'bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] hover:scale-[1.02] hover:shadow-lg hover:shadow-[#8B5CF6]/50'
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            {isApplying ? (
              <>
                <Loader className="w-4 h-4 animate-spin" />
                <span>Applying Patch...</span>
              </>
            ) : isApplied ? (
              <>
                <CheckCircle className="w-4 h-4" />
                <span>Patch Applied</span>
              </>
            ) : (
              <>
                <Shield className="w-4 h-4" />
                <span>Apply Patch</span>
              </>
            )}
          </div>
        </button>
      </div>
    </div>
  );
};
