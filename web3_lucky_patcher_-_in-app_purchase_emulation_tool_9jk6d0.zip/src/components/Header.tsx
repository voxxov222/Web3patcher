import React from 'react';
import { Shield, Wallet, ChevronDown } from 'lucide-react';
import { useWeb3Store } from '../store/useWeb3Store';

export const Header: React.FC = () => {
  const { isConnected, address, balance, connectWallet, disconnectWallet } = useWeb3Store();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0F172A]/80 backdrop-blur-xl border-b border-[#8B5CF6]/20">
      <div className="absolute inset-0 bg-gradient-to-r from-[#3B82F6]/5 via-[#8B5CF6]/5 to-[#10B981]/5" />
      
      <div className="relative max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3 group cursor-pointer">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] rounded-xl blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
              <div className="relative bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6] p-3 rounded-xl">
                <Shield className="w-6 h-6 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-[#3B82F6] via-[#8B5CF6] to-[#10B981] bg-clip-text text-transparent">
                Lucky Patcher
              </h1>
              <p className="text-xs text-[#A3A3A3]">Web3 Edition</p>
            </div>
          </div>

          {/* Network Selector */}
          <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-[#262626]/50 rounded-lg border border-[#2F2F2F] hover:border-[#8B5CF6]/50 transition-colors cursor-pointer">
            <div className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
            <span className="text-sm text-white">Ethereum Mainnet</span>
            <ChevronDown className="w-4 h-4 text-[#A3A3A3]" />
          </div>

          {/* Wallet Connection */}
          {!isConnected ? (
            <button
              onClick={connectWallet}
              className="group relative px-6 py-2.5 bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] rounded-lg font-medium text-white overflow-hidden transition-all hover:scale-105 hover:shadow-lg hover:shadow-[#8B5CF6]/50"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative flex items-center gap-2">
                <Wallet className="w-4 h-4" />
                <span>Connect Wallet</span>
              </div>
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-sm font-medium text-white">{balance} ETH</span>
                <span className="text-xs text-[#A3A3A3]">
                  {address?.slice(0, 6)}...{address?.slice(-4)}
                </span>
              </div>
              <button
                onClick={disconnectWallet}
                className="px-4 py-2 bg-[#262626] rounded-lg border border-[#2F2F2F] hover:border-[#ef4444]/50 text-white text-sm transition-all hover:bg-[#ef4444]/10"
              >
                Disconnect
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
